// orchestration_stackresources_v1
package testing
