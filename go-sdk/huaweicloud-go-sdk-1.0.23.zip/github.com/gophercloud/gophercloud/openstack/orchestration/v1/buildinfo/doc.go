// Package buildinfo provides build information about heat deployments.
package buildinfo
