// Package portsbinding provides information and interaction with the port
// binding extension for the OpenStack Networking service.
package portsbinding
