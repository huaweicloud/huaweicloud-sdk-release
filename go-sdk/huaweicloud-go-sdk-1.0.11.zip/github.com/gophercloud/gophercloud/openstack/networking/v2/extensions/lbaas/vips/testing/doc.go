// vips unit tests
package testing
