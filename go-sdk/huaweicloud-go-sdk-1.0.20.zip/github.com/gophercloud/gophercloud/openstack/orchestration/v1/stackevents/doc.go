// Package stackevents provides operations for finding, listing, and retrieving
// stack events. Stack events are events that take place on stacks such as
// updating and abandoning.
package stackevents
