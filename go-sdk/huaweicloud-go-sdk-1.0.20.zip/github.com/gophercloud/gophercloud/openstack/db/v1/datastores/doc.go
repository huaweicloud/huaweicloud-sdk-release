// Package datastores provides information and interaction with the datastore
// API resource in the Rackspace Database service.
package datastores
