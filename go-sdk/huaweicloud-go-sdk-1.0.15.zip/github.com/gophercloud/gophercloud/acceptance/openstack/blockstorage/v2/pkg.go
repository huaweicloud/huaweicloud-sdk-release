// The v2 package contains acceptance tests for the Openstack Cinder V2 service.

package v2
