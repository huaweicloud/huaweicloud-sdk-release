Java SDK for HUAWEI CLOUD
===========

It is a HUAWEI CLOUD client that allows provisioning and control of an HUAWEI CLOUD deployment. This includes support for Identity, Compute, Image, Network, Block Storage, Telemetry, Data Processing as well as many extensions.

* Website: https://github.com/huaweicloudsdk/sdk-java

