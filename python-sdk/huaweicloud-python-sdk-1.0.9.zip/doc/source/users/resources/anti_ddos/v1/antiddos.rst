openstack.anti_ddos.v1.antiddos
===============================

.. automodule:: openstack.anti_ddos.v1.antiddos

The QueryConfigList Class
-------------------------

The ``QueryConfigList`` class inherits from
      :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.anti_ddos.v1.antiddos.QueryConfigList
   :members:

The FloatingIP Class
--------------------

The ``FloatingIP`` class inherits from
      :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.anti_ddos.v1.antiddos.FloatingIP
   :members:

The TaskStatus Class
--------------------

The ``TaskStatus`` class inherits from
      :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.anti_ddos.v1.antiddos.TaskStatus
   :members:

The EIPStatus Class
-------------------

The ``EIPStatus`` class inherits from
      :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.anti_ddos.v1.antiddos.EIPStatus
   :members:

The EIPDaily Class
-------------------

The ``EIPDaily`` class inherits from
      :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.anti_ddos.v1.antiddos.EIPDaily
   :members:

The EIPWeekly Class
-------------------

The ``EIPWeekly`` class inherits from
      :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.anti_ddos.v1.antiddos.EIPWeekly
   :members:

The EIPLog Class
-------------------

The ``EIPLog`` class inherits from
      :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.anti_ddos.v1.antiddos.EIPLog
   :members:
