openstack.cluster.v1.profile_type
=================================

.. automodule:: openstack.cluster.v1.profile_type

The ProfileType Class
---------------------

The ``ProfileType`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.profile_type.ProfileType
   :members:
