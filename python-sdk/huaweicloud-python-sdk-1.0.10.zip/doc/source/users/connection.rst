Connection
==========
.. automodule:: openstack.connection

   from_config
   -----------
   .. autofunction:: openstack.connection.from_config

Connection Object
-----------------

.. autoclass:: openstack.connection.Connection
   :members:
