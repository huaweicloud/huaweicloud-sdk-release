openstack.map_reduce.v1.job_exe
==========================

.. automodule:: openstack.map_reduce.v1.job_exe

The JobExecution Class
--------------

The ``JobExe`` class inherits from :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.map_reduce.v1.job_exe.JobExe
   :members:
