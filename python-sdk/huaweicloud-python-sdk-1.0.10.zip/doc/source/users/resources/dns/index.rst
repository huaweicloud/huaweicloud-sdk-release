Identity v2 Resources
=====================

.. toctree::
   :maxdepth: 1

   v2/zone
   v2/recordset
   v2/ptr
