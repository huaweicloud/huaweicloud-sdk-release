openstack.network.v2.subnet_pool
================================

.. automodule:: openstack.network.v2.subnet_pool

The SubnetPool Class
--------------------

The ``SubnetPool`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.subnet_pool.SubnetPool
   :members:
