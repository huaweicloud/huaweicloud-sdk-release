openstack.cluster.v1.build_info
===============================

.. automodule:: openstack.cluster.v1.build_info

The BuildInfo Class
-------------------

The ``BuildInfo`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.build_info.BuildInfo
   :members:
