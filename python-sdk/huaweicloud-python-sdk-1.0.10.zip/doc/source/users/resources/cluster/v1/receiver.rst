openstack.cluster.v1.receiver
=============================

.. automodule:: openstack.cluster.v1.receiver

The Reciever Class
------------------

The ``Reciever`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.receiver.Receiver
   :members:
