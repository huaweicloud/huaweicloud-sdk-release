openstack.cluster.v1.cluster_policy
===================================

.. automodule:: openstack.cluster.v1.cluster_policy

The ClusterPolicy Class
-----------------------

The ``ClusterPolicy`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.cluster_policy.ClusterPolicy
   :members:
