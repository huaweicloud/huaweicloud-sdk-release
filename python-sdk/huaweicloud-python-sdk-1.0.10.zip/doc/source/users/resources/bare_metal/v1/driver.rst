openstack.bare_metal.v1.driver
==============================

.. automodule:: openstack.bare_metal.v1.driver

The Driver Class
----------------

The ``Driver`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.bare_metal.v1.driver.Driver
   :members:
