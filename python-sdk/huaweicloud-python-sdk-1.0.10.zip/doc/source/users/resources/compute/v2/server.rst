openstack.compute.v2.server
============================

.. automodule:: openstack.compute.v2.server

The Server Class
----------------

The ``Server`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.compute.v2.server.Server
   :members:
