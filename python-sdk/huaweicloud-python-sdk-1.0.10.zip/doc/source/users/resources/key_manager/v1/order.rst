openstack.key_manager.v1.order
==============================

.. automodule:: openstack.key_manager.v1.order

The Order Class
---------------

The ``Order`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.key_manager.v1.order.Order
   :members:
