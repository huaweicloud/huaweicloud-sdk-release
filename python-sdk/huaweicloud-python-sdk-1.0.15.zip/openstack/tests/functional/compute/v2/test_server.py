# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import uuid
import sys
from openstack.tests.functional import base
from openstack import utils
utils.enable_logging(debug=True, stream=sys.stdout)


class TestServer(base.BaseFunctionalTest):

    NAME = uuid.uuid4().hex
    server = None
    network = None
    subnet = None
    cidr = '10.99.99.0/16'

    @classmethod
    def setUpClass(cls):
        super(TestServer, cls).setUpClass()
        # flavor = cls.conn.compute.find_flavor(base.FLAVOR_NAME,
        #                                       ignore_missing=False)
        # image = cls.conn.compute.find_image(base.IMAGE_NAME,
        #                                     ignore_missing=False)
        # cls.network, cls.subnet = test_network.create_network(cls.conn,
        #                                                       cls.NAME,
        #                                                       cls.cidr)
        # if not cls.network:
        #     # We can't call TestCase.fail from within the setUpClass
        #     # classmethod, but we need to raise some exception in order
        #     # to get this setup to fail and thusly fail the entire class.
        #     raise Exception("Unable to create network for TestServer")
        #
        # sot = cls.conn.compute.create_server(
        #     name=cls.NAME, flavor_id=flavor.id, image_id=image.id,
        #     networks=[{"uuid": cls.network.id}])
        # cls.conn.compute.wait_for_server(sot)
        # assert isinstance(sot, server.Server)
        # cls.assertIs(cls.NAME, sot.name)
        # cls.server = sot
        cls.server = cls.conn.compute.get_server("1658753f-8ab2-4650-be05-5ac8d353c56a")

    @classmethod
    def tearDownClass(cls):
        super(TestServer, cls).tearDownClass()
        # sot = cls.conn.compute.delete_server(cls.server.id)
        # cls.assertIs(None, sot)
        # # Need to wait for the stack to go away before network delete
        # cls.conn.compute.wait_for_delete(cls.server)
        # cls.linger_for_delete()
        # test_network.delete_network(cls.conn, cls.network, cls.subnet)

    # def test_find(self):
    #     sot = self.conn.compute.find_server(self.NAME)
    #     self.assertEqual(self.server.id, sot.id)
    #
    # def test_get(self):
    #     sot = self.conn.compute.get_server(self.server.id)
    #     self.assertEqual(self.NAME, sot.name)
    #     self.assertEqual(self.server.id, sot.id)
    #
    # def test_list(self):
    #     names = [o.name for o in self.conn.compute.servers()]
    #     self.assertIn(self.NAME, names)

    def test_server_metadata(self):
        test_server = self.conn.compute.get_server(self.server.id)

        # get metadata
        test_server = self.conn.compute.get_server_metadata(test_server)
        self.assertFalse(test_server.metadata)

        # set no metadata
        self.conn.compute.set_server_metadata(test_server)
        test_server = self.conn.compute.get_server_metadata(test_server)
        self.assertFalse(test_server.metadata)

        # set empty metadata
        self.conn.compute.set_server_metadata(test_server, k0='')
        server = self.conn.compute.get_server_metadata(test_server)
        self.assertTrue(server.metadata)

        # set metadata
        res = self.conn.compute.set_server_metadata(test_server, k1='v1')

        test_server = self.conn.compute.get_server_metadata(test_server)
        self.assertTrue(test_server.metadata)
        self.assertEqual(2, len(test_server.metadata))
        self.assertIn('k0', test_server.metadata)
        self.assertEqual('', test_server.metadata['k0'])
        self.assertIn('k1', test_server.metadata)
        self.assertEqual('v1', test_server.metadata['k1'])

        # set more metadata
        self.conn.compute.set_server_metadata(test_server, k2='v2')
        test_server = self.conn.compute.get_server_metadata(test_server)
        self.assertTrue(test_server.metadata)
        self.assertEqual(3, len(test_server.metadata))
        self.assertIn('k0', test_server.metadata)
        self.assertEqual('', test_server.metadata['k0'])
        self.assertIn('k1', test_server.metadata)
        self.assertEqual('v1', test_server.metadata['k1'])
        self.assertIn('k2', test_server.metadata)
        self.assertEqual('v2', test_server.metadata['k2'])

        # update metadata
        self.conn.compute.update_server_metadata(test_server, "k0", 'updatek0')
        test_server = self.conn.compute.get_server_metadata(test_server)
        self.assertTrue(test_server.metadata)
        self.assertEqual(3, len(test_server.metadata))
        self.assertEqual('updatek0', test_server.metadata['k0'])

        # delete metadata
        self.conn.compute.delete_server_metadata(
            test_server, test_server.metadata.keys())
        test_server = self.conn.compute.get_server_metadata(test_server)
        self.assertFalse(test_server.metadata)
