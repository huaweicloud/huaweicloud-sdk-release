openstack.network.v2.health_monitor
===================================

.. automodule:: openstack.network.v2.health_monitor

The HealthMonitor Class
-----------------------

The ``HealthMonitor`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.health_monitor.HealthMonitor
   :members:
