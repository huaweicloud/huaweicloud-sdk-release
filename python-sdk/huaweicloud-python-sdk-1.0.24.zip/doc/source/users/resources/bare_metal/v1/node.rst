openstack.bare_metal.v1.Node
============================

.. automodule:: openstack.bare_metal.v1.node

The Node Class
--------------

The ``Node`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.bare_metal.v1.node.Node
   :members:
