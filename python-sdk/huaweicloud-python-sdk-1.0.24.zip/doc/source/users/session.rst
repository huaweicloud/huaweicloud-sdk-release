Session
=======

.. automodule:: openstack.session

Session Object
--------------

.. autoclass:: openstack.session.Session
   :members:
