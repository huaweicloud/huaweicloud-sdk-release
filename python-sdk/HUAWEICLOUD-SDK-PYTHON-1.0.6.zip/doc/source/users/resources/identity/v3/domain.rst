openstack.identity.v3.domain
============================

.. automodule:: openstack.identity.v3.domain

The Domain Class
----------------

The ``Domain`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.identity.v3.domain.Domain
   :members:
