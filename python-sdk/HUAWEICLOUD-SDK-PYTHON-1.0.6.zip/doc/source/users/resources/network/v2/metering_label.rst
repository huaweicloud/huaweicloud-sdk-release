openstack.network.v2.metering_label
===================================

.. automodule:: openstack.network.v2.metering_label

The MeteringLabel Class
-----------------------

The ``MeteringLabel`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.metering_label.MeteringLabel
   :members:
