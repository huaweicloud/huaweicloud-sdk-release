openstack.maas.v1.version
=========================

.. automodule:: openstack.maas.v1.version

The Version Class
-----------------

The ``Agent`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.maas.v1.version.Version
   :members:
