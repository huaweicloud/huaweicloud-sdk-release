openstack.map_reduce.v1.data_source
==========================

.. automodule:: openstack.map_reduce.v1.data_source

The DataSource Class
--------------

The ``DataSource`` class inherits from :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.map_reduce.v1.data_source.DataSource
   :members:
