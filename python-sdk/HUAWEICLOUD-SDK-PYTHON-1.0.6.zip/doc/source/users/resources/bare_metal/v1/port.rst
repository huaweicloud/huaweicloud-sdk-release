openstack.bare_metal.v1.port
============================

.. automodule:: openstack.bare_metal.v1.port

The Port Class
--------------

The ``Port`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.bare_metal.v1.port.Port
   :members:
