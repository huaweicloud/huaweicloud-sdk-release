openstack.telemetry.v2.meter
============================

.. automodule:: openstack.telemetry.v2.meter

The Meter Class
----------------

The ``Meter`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.telemetry.v2.meter.Meter
   :members:
