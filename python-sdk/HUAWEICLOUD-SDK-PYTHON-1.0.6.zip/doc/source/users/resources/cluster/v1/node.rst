openstack.cluster.v1.Node
=========================

.. automodule:: openstack.cluster.v1.node

The Node Class
--------------

The ``Node`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.cluster.v1.node.Node
   :members:
