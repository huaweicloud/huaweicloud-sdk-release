Python SDK of HUAWEI CLOUD
====================

This SDK is under active development, and in the interests of providing
a high-quality interface, the APIs provided in this release may differ
from those provided in future release.

https://github.com/huaweicloudsdk/sdk-python/
