openstack.rds_os.v1.flavor
==========================

.. automodule:: openstack.rds_os.v1.flavor

The Flavor Class
----------------

The ``Flavor`` class inherits from
    :class:`~openstack.rds_os.v1.rds_osresource.Resource`.

.. autoclass:: openstack.rds_os.v1.flavor.Flavor
   :members:
