openstack.map_reduce.v1.job_binary
==========================

.. automodule:: openstack.map_reduce.v1.job_binary

The JobBinary Class
--------------

The ``JobBinary`` class inherits from :class:`~openstack.resource2.Resource`.

.. autoclass:: openstack.map_reduce.v1.job_binary.JobBinary
   :members:
