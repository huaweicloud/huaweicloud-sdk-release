openstack.object_store.v1.account
=================================

.. automodule:: openstack.object_store.v1.account

The Account Class
-----------------

The ``Account`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.object_store.v1.account.Account
   :members:
